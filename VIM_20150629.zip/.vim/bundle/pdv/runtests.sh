#!/bin/bash
runVimTests.sh --source `pwd`/autoload/pdv.vim ${1-tests/}
