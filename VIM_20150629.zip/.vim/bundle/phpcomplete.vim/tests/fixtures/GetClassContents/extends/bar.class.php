<?php

class BarClass { }
