<?php

class BazClass { }
