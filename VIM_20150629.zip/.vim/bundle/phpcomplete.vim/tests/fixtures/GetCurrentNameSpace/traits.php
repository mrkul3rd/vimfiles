<?php
namespace NS1;
use DateTime;

trait SomeTrait {

}

class Foo {
	use SomeTrait;
}

