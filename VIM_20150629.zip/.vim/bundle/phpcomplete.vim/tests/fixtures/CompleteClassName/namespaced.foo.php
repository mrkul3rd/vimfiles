<?php
namespace NS1;

class NameSpacedFoo {
}

interface NameSpacedFooInterface {
}
