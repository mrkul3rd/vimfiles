#!/bin/bash
runVimTests.sh --source `pwd`/autoload/vmustache.vim ${1-tests/}
